---
name: Bug report
about: Reportar um bug
title: "[BUG] "
labels: bug
---

**Descreva o bug**
Descrição clara do bug.

**Como reproduzir**
1. Vá para '...'
2. Clique em '...'
3. Erro!

**Esperado**
O que deveria acontecer.

**Logs**
Cole o `latest.log` ou crash report.

**Versões:**
- Minecraft: [ex: 1.20.1]
- Fabric Loader: [ex: 0.15.7]
- BoatMod: [ex: 1.0.0]
